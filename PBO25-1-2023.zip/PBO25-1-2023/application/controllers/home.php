<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	public function index()
	{
		$data['vocer'] =	$this->db->get('vocer')->result_array();
		$this->load->view('home',$data);
		
	}
	// public function update($id)
	// {
	// 	$data['id']=$id;
	// 	$this->load->view('update',$data);
		
	// }
	public function tambah()
	{
		$this->load->view('tambah');
		
	}
	

	public function proses_tambah()
	{
		// $this->load->view('tambah');
		$data = [
			'id' => $this->input->post('id'),
			'nama_operator' => $this->input->post('nama_operator'),
			'jumlah_pulsa' => $this->input->post('jumlah_pulsa')
		];
		// $data = array(
		// 	$id => $this->input->post('id'),
		// 	$nama_operator => $this->input->post('nama_operator'),
		// 	$jumlah_pulsa => $this->input->post('jumlah_pulsa')
		// );

		$query = $this->db->insert('vocer', $data);
		if ($query) {
			redirect('home');
		}
	}
	function proses_update($id){
		$data = array(
			'nama_operator' => $this->input->post('nama_operator'),
			'jumlah_pulsa' => $this->input->post('jumlah_pulsa'));
			
			$this->db->where('id',$id);

			$query = $this->db->where('id',$id)->update('vocer',$data);

			if($query){
				redirect('home');
			}	
	}
	function update($id){
		$data['id'] = $id;
		$this->load->view('update', $data);
	}	
	
	function proses_hapus(){
		$id = $this->input->get('id');
		$query = $this->db->delete('vocer',array('id'=>$id));
		if($query){
			redirect('home');
		}
	}
	// function proses_edit(){
	// 	$id = $this->input->post('id');
	// 	$nama_operator = $this->input->post('nama_operator');
	// 	$jumlah_pulsa = $this->input->post('jumlah_pulsa');
	 
	// 	$data = array(
	// 		'id' => $id,
	// 		'nama_operator' => $nama_operator,
	// 		'jumlah_pulsa' => $jumlah_pulsa,
	// 	);
	 
	// 	$id = array(
	// 		'id' => $id
	// 	);
	 
	// 	$this->db->proses_edit($id,$data,'user');
	// 	redirect('home');
	// }
	// public function proses_edit($id)
	// {
	// 	// $this->load->view('tambah');
	
	// 	// unction edit($id){
	// 	$data = array('id' => $id);
	// 	$data['vocer'] = $this->load->edit_data($data,'vocer')->result();
	// 	$this->load->view('edit',$data);
	// 	// $data = [
	// 	// 	'id' => $this->input->post('id'),
	// 	// 	'nama_operator' => $this->input->post('nama_operator'),
	// 	// 	'jumlah_pulsa' => $this->input->post('jumlah_pulsa')
	// 	// ];

	// 	// $query = $this->db->update('vocer', $data);
	// 	// if ($query) {
	// 		redirect('edit');
		
	// }
	// public function delete($id)
    // {
    //     return $this->db->delete($this->home, array("IdMhsw" => $id));
    // }
	
	// function hapus($id){
	// 	$where = array('id' => $id);
	// 	$this->m_data->hapus_data($where,'user');
	// 	redirect('crud/index');
	// }
	
	
	// public function delete($id){
	// 	$data = $this->db->delete('pulsa',array('id' => $id));
	// 	// $this->db->delete('vocer');

	// 	redirect('home');
	// }

}
