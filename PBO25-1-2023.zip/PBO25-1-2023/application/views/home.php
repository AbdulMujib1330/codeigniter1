<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Home</title>
</head>
<body>
    <!-- <h1>Haiii</h1> -->
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Nama Operator</th>
      <th scope="col">Jumlah Pulsa</th>
      <th scope="col">#</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach ($vocer as $data) : ?>
    <tr>
      <th scope="row">  <?= $data ['id'] ?></th>
      <td>              <?= $data ['nama_operator'] ?></td>
      <td>              <?= $data ['jumlah_pulsa']?></td>
      <td>
      <a href="home/update/<?= $data['id'] ?>">Edit</a>  
      <a href="home/proses_hapus?id=<?= $data['id'] ?>">Hapus</a>
      </td>
    </tr>
    <tr>
    <?php endforeach; ?>
  </tbody>
</table>
    <a class="btn btn-primary" href="<?php echo site_url('tambah')?>">Tambah</a>
</body>
</html>