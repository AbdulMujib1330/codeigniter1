<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
<!DOCTYPE html>
<html lang="en">
<head>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="	https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
<title>Tambahj</title>
</head>
<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
<body>
<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
<form action="<?php echo site_url('home/proses_tambah')?>" method="post">
<section class="vh-100 gradient-custom">
<div class="container py-5 h-100">
  <div class="row d-flex justify-content-center align-items-center h-100">
    <div class="col-12 col-md-8 col-lg-6 col-xl-5">
      <div class="card bg-light text-white border-dark" style="border-radius: 1rem;">
        <div class="card-body p-5 py-2 text-center">

          <div class="mb-md-5 mt-md-4 pb-5">

            <h2 class="fw-bold mb-2 text-uppercase text-dark">Vocer</h2>
            <!-- <p class="text-white-50 mb-5"></p> -->

            <div class="form-outline form-white mb-4">
              <input type="name" name="nama_operator" id="typeEmailX" class="border-dark form-control form-control-lg" />
              <label class="form-label text-dark" for="typeEmailX">Nama Operator</label>
            </div>

            <div class="form-outline form-white mb-4">
              <input type="number" name="jumlah_pulsa" id="typePasswordX" class="border-dark form-control form-control-lg" />
              <label class="form-label text-dark" for="typePasswordX">Jumlah Pulsa</label>
            </div>


            <button class="btn btn-outline-dark btn-lg px-5" type="submit">Submit</button>

          </div>

          <div>
            <a onclick="return confirm('Ingin Keluar?')"  href="<?php echo site_url('home')?>" class="">Home</a>
            </p>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>
</section>
<!-- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ -->
</body>
</html>
